<?php
/**
 * My Serial Keys
 *
 * Shows all serial keys of purchased products
 *
 * @author 		Store Apps
 * @package 	woocommerce-serial-key/templates
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<style>
	span.serial_key {
		float: right;
	}
	.serial_keys {
		color: #000;
	}
</style>
<h3><?php echo apply_filters( 'woocommerce_my_serial_key_title', $title ); ?></h3>

<ul class="serial_keys">
	<?php foreach ( $serial_keys as $product_id => $serial_key ) { ?>
		<li>
			<?php
				do_action( 'woocommerce_my_serial_key_start', $product_id, $serial_key );

				//echo apply_filters( 'woocommerce_my_serial_key_product_serial_key', '<span class="serial_key">' . $serial_key . '</span> ', $serial_key );
 				echo apply_filters( 'woocommerce_my_serial_key_product_serial_key', '<span class="serial_key"><a href="biolink://nhor/'.$product_id.'/'.$serial_key.'/" target="_blank">' . $serial_key . '</a></span> ', $serial_key );

//CURL request to check validation and display expiration.
$url = 'https://www.thenewhuman.com/?wc-api=validate_serial_key&serial='.$serial_key.'&sku='.$product_id.'&uuid=UUID';
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL,$url);
$result = curl_exec($ch);
curl_close($ch);
$result_found = json_decode($result, true);

				echo apply_filters( 'woocommerce_my_serial_key_product_title', SA_Serial_Key::get_product_title( $product_id ), $product_id );

echo ' (Expires: ';
//echo $result_found['expires'];
echo $reformatted_date = date("F d, Y g:ia", strtotime($result_found['expires']));
echo ')';

				do_action( 'woocommerce_my_serial_key_end', $product_id, $serial_key );
			?>
		</li>
	<?php } ?>
</ul>