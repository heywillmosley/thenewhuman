<?php
/**
 * My Serial Keys
 *
 * Shows all serial keys of purchased products
 *
 * @author 		Store Apps
 * @package 	woocommerce-serial-key/templates
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Check if Admin before displaying script
if( !is_admin() ) {

	if(is_page('my-account') || is_page('account')) {

		do_action( 'woocommerce_my_serial_key_start', $product_id, $serial_key );
		?>
		<style>
			span.serial_key {
				float: right;
			}
			.serial_keys {
				color: #000;
			}
			.alert h2 {
				margin-top: 0;
			}
		</style>
		
		<div class="alert alert-success" role="alert">
			<h2><i class="fa fa-key" aria-hidden="true"></i> Need to register your software? It's super simple!</h2>
			<ol>
				<li>IMPORTANT: Make sure to download the latest software and install it. <a href="http://biolinkconnect.com/Downloads/InstallBionetics.exe" target="_blank">Download</a></li>
				<li>Follow these simple instructions: <a href="https://www.thenewhuman.com/software-registration/">An Easier Way to Register Your Software</a></li>
			</ol>
		</div><!-- end alert -->
		<a href="https://www.thenewhuman.com/software-registration/"><img src="https://www.thenewhuman.com/wp-content/uploads/2016/12/bionetics-register.png" alt="How to Register" /></a>
		<ul class="serial_keys">
			<?php 
			$uid = get_current_user_id();
			$count = 1;
			$computer_count = 1;


			// Get SERIAL KEY of Doctor and Match
		    // Use print_r($customer_orders)
			$customer_orders = get_posts( array(
			    'numberposts' => -1,
			    'meta_key'    => '_customer_user',
			    'meta_value'  => $uid,
			    'post_type'   => wc_get_order_types(),
			    'post_status' => array_keys( wc_get_order_statuses() ),
			) );

		    // Get Order IDs
		    foreach ($customer_orders as &$order) {
				    $order_ids[] = $order->ID;
			}

			// Get all Serial Orders by ID
			//print_r($serial_orders);
			$serial_orders= $wpdb->get_col("SELECT `order_id` FROM `wp_woocommerce_serial_key`");

			$result = array_intersect($order_ids, $serial_orders);

			foreach ( array_reverse($result) as $order_id ) { ?>
				<li>
					<?php
					$serial_key = $wpdb->get_var("SELECT `serial_key` FROM `wp_woocommerce_serial_key` WHERE `order_id` = '$order_id'");
					$the_date = $wpdb->get_var("SELECT `valid_till` FROM `wp_woocommerce_serial_key` WHERE `order_id` = '$order_id'");
					$pretty_exp = date_format(date_create($the_date), 'M d, Y');

					$pcid = $wpdb->get_var("SELECT `pcid` FROM `wp_woocommerce_serial_key` WHERE `order_id` = '$order_id'");

					if($pcid == NULL) {
						$pcid_count = 0;
					}
					else {
						$pcid = explode(",",$pcid);
						$pcid_count = count($pcid);
					}
					
					$remaining_computers = 2 - $pcid_count;


					// Singular or Plural
					if($pcid_count == 0) {
						$computer = 'computers';
					}
					else {
						$computer = 'computer';
					}

					if(strtotime($the_date) < strtotime("now")) {
						$is_exp = TRUE;
					}
					else {
						$is_exp = FALSE;
					}

					echo '<hr/><p>Order #' . $order_id;

					// Return Expired Label if expired
					if($is_exp) {
						echo ' <span class="label label-danger">Key Expired</span>';
					}

					echo '</p>';

					echo '<h4>Serial Key ' . $count . ' <small>(';

					if($pcid_count == 0 && !$is_exp) {
						echo 'Start using this key by following the instructions above.';
					}
					else {
						echo $serial_key;
					}

					echo ')</small></h4>';
					
					if(!$is_exp) {
						echo '<p>This Key expires on <strong class="text-danger">' . $pretty_exp . '</strong> and has been registered to <strong>' . $pcid_count . ' ' . $computer . '.</strong><br/>';

						if($pcid_count < 2) {
							echo 'You may use this key for <strong>' . $remaining_computers . ' more ' . $computer . '</strong> before having to purchase another key.';
						}	
						else {
							'You have used this key on 2 computers. Please use another key or purchase another key here: <a href="https://www.thenewhuman.com/shop/software-renewal-2/">here</a>';
						}

					} // end !is_exp
					else {
						echo 'This Key has expired. And may no longer be used.';
					}
					

					if($pcid_count != 0) {
						echo '<p class="text-info">This key is registered on the following computer(s):<br/>';

						foreach ($pcid as $key) {
							echo '<p>Computer ' . $computer_count . ': <em>' . $key . '</em></p>'; 
							$computer_count++;
						}

					}
					$computer_count = 1;

					echo '<br/><br/>';
					
					$count++;
					

					// Get each key from DB & Associated PCIDs, & Exp

						

						//echo apply_filters( 'woocommerce_my_serial_key_product_serial_key', '<span class="serial_key">' . $serial_key . '</span> ', $serial_key );
		 				//echo apply_filters( 'woocommerce_my_serial_key_product_serial_key', '<span class="serial_key"><a href="biolink://nhor/'.$product_id.'/'.$serial_key.'/" target="_blank">' . $serial_key . '</a></span> ', $serial_key );

		//CURL request to check validation and display expiration.
		//$url = 'https://www.thenewhuman.com/?wc-api=validate_serial_key&serial='.$serial_key.'&sku='.$product_id.'&uuid=UUID';
		//$ch = curl_init();
		//curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		//curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		//curl_setopt($ch, CURLOPT_URL,$url);
		//$result = curl_exec($ch);
		//curl_close($ch);
		//$result_found = json_decode($result, true);

						//echo apply_filters( 'woocommerce_my_serial_key_product_title', SA_Serial_Key::get_product_title( $product_id ), $product_id );

		//echo ' (Expires: ';
		//echo $result_found['expires'];
		//echo $reformatted_date = date("F d, Y g:ia", strtotime($result_found['expires']));
		//echo ')';

						do_action( 'woocommerce_my_serial_key_end', $product_id, $serial_key );

					?>
				</li>
			<?php } ?>
		</ul>
		
		<div style="display:none"><hr/><a href="#" class="btn btn-danger">Unregister all of my computers</a> This action can not be undone.</div>

	<?php } // end if(is_page('my-account') || is_page('account')) 

} // end if admin ?>