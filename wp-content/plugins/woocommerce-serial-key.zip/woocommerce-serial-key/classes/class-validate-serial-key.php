<?php
if ( !defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'Validate_Serial_Key' ) ) {

	class Validate_Serial_Key {

		var $callback;

		public function __construct() {
			
			$this->callback = strtolower( esc_attr( __CLASS__ ) );

			add_action( 'woocommerce_api_'.$this->callback, array( $this, 'validate_serial_key' ) );
			add_filter( 'woocommerce_validate_serial_key', array( $this, 'woocommerce_validate_serial_key' ), 10, 3 );

		}

		public function validate_serial_key() {

			$serial_key = ( !empty( $_REQUEST['serial'] ) ) ? $_REQUEST['serial'] : '';
			$product_sku = ( !empty( $_REQUEST['sku'] ) ) ? $_REQUEST['sku'] : '';
			$uuid = ( !empty( $_REQUEST['uuid'] ) ) ? $_REQUEST['uuid'] : '';

			echo apply_filters( 'woocommerce_validate_serial_key', $serial_key, $product_sku, $uuid );
			exit;

		}

		public function woocommerce_validate_serial_key( $serial_key = NULL, $product_sku = NULL, $current_uuid = NULL ) {

			global $wpdb, $sa_serial_key;

			$return = false;
			$message = array();

			if ( empty( $serial_key ) ) {
				$return = true;
				$message[] = __( 'Serial Key empty', SA_Serial_Key::$text_domain );
			}

			if ( empty( $product_sku ) ) {
				$return = true;
				$message[] = __( 'SKU empty', SA_Serial_Key::$text_domain );
			}

			if ( $return ) {
				$result = array( 'success' => 'false', 'message' => implode( ', ', $message ) );
				return json_encode( $result );
			}

			$query = "SELECT `order_id`, `product_id`, `limit`, `uuid` FROM {$wpdb->prefix}woocommerce_serial_key WHERE serial_key = '" . $serial_key . "'";
			$result = $wpdb->get_row( $query, 'ARRAY_A' );
			
			if ( empty( $result ) ) {
				return json_encode( array( 'success' => 'false', 'message' => __( 'Serial key not found', SA_Serial_Key::$text_domain ) ) );
			}

			$valid_uuids = ( !empty( $result['uuid'] ) ) ? maybe_unserialize( $result['uuid'] ) : array();
			$limit = ( !empty( $result['limit'] ) ) ? absint( $result['limit'] ) : '';
			$is_new_uuid = false;

			if ( !empty( $limit ) && count( $valid_uuids ) > $limit && !in_array( $current_uuid, $valid_uuids ) ) {
				return json_encode( array( 'success' => 'false', 'message' => __( 'Serial key usage exceeded the allowed limit', SA_Serial_Key::$text_domain ) ) );
			}

			if ( !empty( $limit ) && count( $valid_uuids ) <= $limit ) {
				if ( !in_array( $current_uuid, $valid_uuids ) ) {
					if ( count( $valid_uuids ) == $limit ) {
						return json_encode( array( 'success' => 'false', 'message' => __( 'Serial key usage exceeded the allowed limit', SA_Serial_Key::$text_domain ) ) );
					} else {
						$valid_uuids[] = $current_uuid;
						$is_new_uuid = true;
					}
				}
			}

			$order = $sa_serial_key->get_order( $result['order_id'] );

			$is_valid_order_status = false;

			if ( ! $order instanceof WC_Order ) {
				$is_valid_order_status = false;
			} elseif ( $sa_serial_key->is_wc_gte_22() ) {
				$current_status = $order->get_status();
				if ( $current_status == 'completed' || $current_status == 'processing' ) {
					$is_valid_order_status = true;
				}
			} else {
				if ( $order->status == 'completed' || $order->status == 'processing' ) {
					$is_valid_order_status = true;
				}
			}

			if ( $is_valid_order_status ) {
				
				$found_sku = get_post_meta( $result['product_id'], '_sku', true );
				if ( empty( $found_sku ) ) {
					$parent_id = wp_get_post_parent_id ( $result['product_id'] );
					$found_sku = get_post_meta( $parent_id, '_sku', true );
					if ( empty( $found_sku ) ) {
						return json_encode( array( 'success' => 'false', 'message' => __( 'Serial key invalid for this product', SA_Serial_Key::$text_domain ) ) );
					}
				}

				if ( stripos( $found_sku, $product_sku ) === false ) {
					return json_encode( array( 'success' => 'false', 'message' => __( 'Serial key invalid for this product', SA_Serial_Key::$text_domain ) ) );
				}

				$product_id = $result['product_id'];

				$download_status_query = "SELECT downloads_remaining, access_expires
											FROM {$wpdb->prefix}woocommerce_downloadable_product_permissions
											WHERE order_id = $order->id
												AND product_id = $product_id
											";
				$download_status = $wpdb->get_row( $download_status_query, 'ARRAY_A' );
				
				if ( $download_status['downloads_remaining'] == '0' ) {
					return json_encode( array( 'success' => 'false', 'message' => __( 'Sorry, you have reached your download limit for this product', SA_Serial_Key::$text_domain ) ) );
				}

				if ( $download_status['access_expires'] > 0 && strtotime( $download_status['access_expires'] ) < current_time( 'timestamp' ) ) {
					return json_encode( array( 'success' => 'false', 'message' => __( 'Sorry, this download has expired', SA_Serial_Key::$text_domain ) ) );
				}

				$parent_id = wp_get_post_parent_id( $product_id );
		
				if ( $parent_id > 0 ) {
					$_product = new WC_Product_Variation( $product_id );
				} else {
					$_product = $sa_serial_key->get_product( $product_id );
				}

				$post_id = ( !empty( $_product->variation_id ) ) ? $_product->variation_id : $_product->id;

				if ( !$_product->is_downloadable() || get_post_meta( $post_id, '_serial_key', true ) !== 'yes' ) {
					return json_encode( array( 'success' => 'false', 'message' => __( 'Serial key invalid for this product', SA_Serial_Key::$text_domain ) ) );
				}

				if ( $is_new_uuid ) {
					$wpdb->query( "UPDATE {$wpdb->prefix}woocommerce_serial_key SET uuid = '" . maybe_serialize( $valid_uuids ) . "' WHERE order_id = " . $order->id . " AND product_id = " . $post_id );
				}

				return json_encode( array( 'success' => 'true', 'message' => __( 'Serial key valid', SA_Serial_Key::$text_domain ) ) );
				
			}

			return json_encode( array( 'success' => 'false', 'message' => __( 'Invalid order', SA_Serial_Key::$text_domain ) ) );

		}

	}

}

global $sa_serial_key;

if ( $sa_serial_key->is_wc_gte_24() ) {
	new Validate_Serial_Key();
}