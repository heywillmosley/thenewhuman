<?php
class SA_Serial_Key {

	public function __construct( $file ) {

        add_action( 'init', array( $this, 'serial_key_text_domain' ) );
        add_action( 'admin_init', array( $this, 'add_my_serial_keys_page' ) );
        add_action( 'admin_init', array( $this, 'sync_serial_key_usage_action' ) );
        add_action( 'admin_menu', array( $this, 'woocommerce_serial_key_admin_menu' ) );

        add_action( 'woocommerce_product_options_downloads', array( $this, 'woocommerce_product_options_serial_key_simple' ) );
        add_action( 'woocommerce_product_after_variable_attributes', array( $this, 'woocommerce_product_options_serial_key_variable' ), '', 3 );
        add_action( 'woocommerce_product_after_variable_attributes_js', array( $this, 'woocommerce_product_options_serial_key_variable_js' ) );
        
        // Actions to save option to generate serial key
        add_action( 'woocommerce_process_product_meta', array( $this, 'woocommerce_process_product_meta_serial_simple' ));
        add_action( 'woocommerce_process_product_meta_variable', array( $this, 'woocommerce_process_product_meta_variable_serial' ));

        // Actions on order status change
        add_action( 'woocommerce_order_status_completed', array($this, 'generate_serial_key_from_order') );
        add_action( 'add_meta_boxes', array($this, 'serial_key_details') );
        
        // Filter for including serial key in e-mail
        add_action( 'woocommerce_before_my_account', array( $this, 'display_serial_keys_of_products' ) );
        add_action( 'woocommerce_email_after_order_table', array( $this, 'display_serial_keys_after_order_table' ) );
        
        // Action to search coupon based on email ids in customer email postmeta key
        add_action( 'parse_request', array( $this,'filter_orders_using_serial_key' ) );
        add_filter( 'get_search_query', array( $this,'filter_orders_using_serial_key_label' ) );

        add_shortcode( 'manage_serial_key_usage', array( $this, 'manage_serial_key_usage_page_content' ) );
        add_filter( 'serial_key_usage_template', array( $this, 'serial_key_usage_template_path' ) );

        add_action( 'wp_ajax_update_serial_key', array( $this, 'ajax_update_serial_key' ) );
        add_action( 'wp_ajax_generate_serial_key', array( $this, 'ajax_generate_serial_key' ) );
        
        // Filter to make all Serial Key Meta Protected
        add_filter( 'is_protected_meta', array( $this, 'make_sk_meta_protected' ), 10, 3 );

	}

    /**
     * to handle WC compatibility related function call from appropriate class
     * 
     * @param $function_name string
     * @param $arguments array of arguments passed while calling $function_name
     * @return result of function call
     * 
     */
    public function __call( $function_name, $arguments = array() ) {

        if ( ! is_callable( 'SA_WC_Compatibility_2_3', $function_name ) ) return;

        if ( ! empty( $arguments ) ) {
            return call_user_func_array( 'SA_WC_Compatibility_2_3::'.$function_name, $arguments );
        } else {
            return call_user_func( 'SA_WC_Compatibility_2_3::'.$function_name );
        }

    }

    function serial_key_text_domain() {
		load_plugin_textdomain( 'localize_woocommerce_serial_key', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

    function add_my_serial_keys_page() {
        global $wpdb;

        if ( get_option( 'my_serial_keys_page_id' ) !== false ) {
            return;
        }

        $slug = 'my_serial_keys';
        $option = 'my_serial_keys_page_id';
        $page_title = __( 'Manage Serial Key Usage', 'woocommerce' );
        $page_content = '[manage_serial_key_usage]';
        $post_parent = woocommerce_get_page_id( 'myaccount' );
        $option_value = get_option( $option );

        if ( $option_value > 0 && get_post( $option_value ) )
                return;

        $page_found = $wpdb->get_var("SELECT ID FROM " . $wpdb->posts . " WHERE post_name = '{$slug}' LIMIT 1;");
        if ( $page_found ) :
                if ( ! $option_value || $option_value != $page_found )
                        update_option( $option, $page_found );
                return;
        endif;

        $page_data = array(
            'post_status'       => 'publish',
            'post_type'         => 'page',
            'post_author'       => 1,
            'post_name'         => $slug,
            'post_title'        => $page_title,
            'post_content'      => $page_content,
            'post_parent'       => $post_parent,
            'comment_status'    => 'closed'
        );
        $page_id = wp_insert_post( $page_data );

        update_option( $option, $page_id );
    }

    function sync_serial_key_usage_action() {
        if ( isset( $_REQUEST['sync_serial_key_usage'] ) && $_REQUEST['sync_serial_key_usage'] == 1 ) {
            $this->sync_serial_key_usage( true );
        }
    }

    function woocommerce_serial_key_admin_menu() {
        add_submenu_page('woocommerce', __( 'Serial Key', 'localize_woocommerce_serial_key' ), __( 'Serial Key', 'localize_woocommerce_serial_key' ), 'manage_woocommerce', 'woocommerce_serial_key', array($this, 'woocommerce_serial_key_page_content') );
    }

    // Funtion to show search result based on serial key in order
    function filter_orders_using_serial_key( $wp ){
        global $pagenow, $wpdb;

        if( 'edit.php' != $pagenow ) return;
        if( !isset( $wp->query_vars['s'] ) ) return;
        if ($wp->query_vars['post_type']!='shop_order') return;

        $e = substr( $wp->query_vars['s'], 0, 6 );

        if( 'serial:' == substr( $wp->query_vars['s'], 0, 7 ) ) {

            $serial = trim( substr( $wp->query_vars['s'], 7 ) );

            if( !$serial ) return;

            $post_ids = $wpdb->get_col( "SELECT order_id FROM {$wpdb->prefix}woocommerce_serial_key WHERE serial_key LIKE '%$serial%'" );

            if( !$post_ids ) return;

            unset( $wp->query_vars['s'] );

            $wp->query_vars['post__in'] = $post_ids;

            $wp->query_vars['serial'] = $serial;
        }
            
    }
    
    // Function to show label of the search result on serial key
    function filter_orders_using_serial_key_label( $query ){
        global $pagenow, $typenow, $wp;

        if ( 'edit.php' != $pagenow ) return $query;
        if ( $typenow!='shop_order' ) return $query;

        $s = get_query_var( 's' );
        if ($s) return $query;

        $serial = get_query_var( 'serial' );

        if( $serial ) {

            $post_type = get_post_type_object($wp->query_vars['post_type']);
            return sprintf(__("%s with Serial Key %s", 'localize_woocommerce_serial_key'), $post_type->labels->singular_name, $serial);
        }

        return $query;
    }
    
    //
    function serial_key_details() {
        global $post;
        
        if ( $post->post_type !== 'shop_order' ) return;
        
        add_meta_box( 'woocommerce-serial-key-details', __('Serial Key Details', 'localize_woocommerce_serial_key'), array( $this, 'woocommerce_serial_key_details_meta_box' ), 'shop_order', 'normal');
    }

    function ajax_generate_serial_key() {

        check_ajax_referer( 'sa_serial_key_ajax', 'security' );

        $target_item = ( ! empty( $_POST['target_item'] ) ) ? $_POST['target_item'] : '';
        $target_item = explode( '_', $target_item );
        $reverse_target_item = array_reverse( $target_item );
        $product_id = ( ! empty( $reverse_target_item[0] ) ) ? $reverse_target_item[0] : 0;
        $order_id = ( ! empty( $reverse_target_item[1] ) ) ? $reverse_target_item[1] : 0;

        $html = '';

        $this->woocommerce_generate_serial_key( $order_id, array( $product_id ) );

        ob_start();
        $this->serial_key_meta_box_content( $order_id );
        $html = ob_get_clean();

        echo $html;
        die();        

    }
    
    function ajax_update_serial_key() {

        check_ajax_referer( 'sa_serial_key_ajax', 'security' );

        global $wpdb;

        $serial_key = ( ! empty( $_POST['serial_key'] ) ) ? $_POST['serial_key'] : '';
        $target_element = ( ! empty( $_POST['target_element'] ) ) ? $_POST['target_element'] : '';
        $target_element = explode( '_', $target_element );
        $reverse_target_element = array_reverse( $target_element );
        $product_id = ( ! empty( $reverse_target_element[0] ) ) ? $reverse_target_element[0] : 0;
        $order_id = ( ! empty( $reverse_target_element[1] ) ) ? $reverse_target_element[1] : 0;

        $response = array();

        $success = true;
        $fields = array();

        if ( empty( $serial_key ) ) {
            $fields[] = __( 'Serial Key', 'localize_woocommerce_serial_key' );
            $success = false;
        }

        if ( empty( $product_id ) ) {
            $fields[] = __( 'Product ID', 'localize_woocommerce_serial_key' );
            $success = false;
        }

        if ( empty( $order_id ) ) {
            $fields[] = __( 'Order ID', 'localize_woocommerce_serial_key' );
            $success = false;
        }

        if ( ! $success ) {
            $response['success'] = 'no';
            $response['message'] = __( '<span class="dashicons dashicons-no-alt" style="color:#a00"></span>&nbsp;Invalid Value for ', 'localize_woocommerce_serial_key' ) . implode( ', ', $fields );
        } else {
            $find_serial_key_query = $wpdb->prepare( "SELECT order_id, product_id FROM {$wpdb->prefix}woocommerce_serial_key WHERE serial_key = %s", $serial_key );
            $found_serial_key = $wpdb->get_results( $find_serial_key_query, 'ARRAY_A' );

            if ( ! empty( $found_serial_key ) ) {
                $response['success'] = 'no';
                $response['message'] = sprintf(__( '<span class="dashicons dashicons-info" style="color:#edbb00"></span>&nbsp;This Key is Already Used in %s', 'localize_woocommerce_serial_key' ), '<a href="' . admin_url( 'post.php?post=' . $found_serial_key[0]['order_id'] . '&action=edit#woocommerce-serial-key-details' ) . '" target="_blank">Order #' . $found_serial_key[0]['order_id'] . '</a>' );
            } else {
                $update_serial_key_query = $wpdb->prepare( "UPDATE {$wpdb->prefix}woocommerce_serial_key SET serial_key = %s WHERE order_id = %d AND product_id = %d", $serial_key, $order_id, $product_id );
                $updated_serial_key = $wpdb->query( $update_serial_key_query, 'ARRAY_A' );

                if ( ! empty( $updated_serial_key ) ) {
                    $response['success'] = 'yes';
                    $response['message'] = __( '<span class="dashicons dashicons-yes" style="color:#26a65b;"></span>&nbsp;Serial Key Updated Successfully', 'localize_woocommerce_serial_key' );
                } else {
                    $response['success'] = 'no';
                    $response['message'] = __( '<span class="dashicons dashicons-no-alt" style="color:#ff0000"></span>&nbsp;Could Not Update Serial Key', 'localize_woocommerce_serial_key' );
                }
            }
        }

        echo json_encode( $response );
        die();
    }

    //
    function woocommerce_serial_key_details_meta_box() {
        global $wpdb, $post;

        $js = "
                function handle_edit_serial_key( element ) {
                    var source_element = element.attr('id');
                    var target_element = source_element.replace( \"edit_serial_key_\", \"serial_key_\" );
                    var target_message_element = target_element.replace( \"serial_key_\", \"message_row_\" );
                    if ( jQuery('#'+target_element).is('[disabled]') ) {
                        jQuery('#'+source_element).removeClass('dashicons-edit').addClass('dashicons-update');
                        jQuery('#'+target_element).removeAttr('disabled');
                        jQuery('#'+target_message_element+' td:nth-child(2)').find('label').html( '' );
                    } else {
                        jQuery.ajax({
                            url: '" . admin_url( 'admin-ajax.php' ) . "',
                            dataType: 'json',
                            type: 'post',
                            data: {
                                action: 'update_serial_key',
                                security: '" . wp_create_nonce( 'sa_serial_key_ajax' ) . "',
                                target_element: target_element,
                                serial_key: jQuery('#'+target_element).val()
                            },
                            success: function ( response ) {
                                if ( response != '' && response != undefined ) {
                                    if ( response.success == 'yes' ) {
                                        jQuery('#'+source_element).removeClass('dashicons-update').addClass('dashicons-edit');
                                        jQuery('#'+target_element).prop('disabled', true);
                                    } else {
                                        jQuery('#'+source_element).removeClass('dashicons-edit').addClass('dashicons-update');
                                    }
                                    jQuery('#'+target_message_element+' td:nth-child(2)').find('label').html( '' );
                                    jQuery('#'+target_message_element+' td:nth-child(2)').find('label').html( response.message );
                                    jQuery('#'+target_message_element).show();
                                }
                            }
                        });
                    }
                }

               jQuery('#sa_serial_key').find('[id^=\"edit_serial_key_\"]').on('click', function(){
                    handle_edit_serial_key( jQuery(this) );
                });

                jQuery('a[id^=\"generate_serial_key_\"]').on('click', function( e ){
                    e.preventDefault();
                    var target_item = jQuery(this).attr('id');
                    jQuery.ajax({
                        url: '" . admin_url( 'admin-ajax.php' ) . "',
                        dataType: 'html',
                        type: 'post',
                        data: {
                            action: 'generate_serial_key',
                            security: '" . wp_create_nonce( 'sa_serial_key_ajax' ) . "',
                            target_item: target_item
                        },
                        success: function ( response ) {
                            if ( response != '' && response != undefined ) {
                                jQuery('div#woocommerce-serial-key-details').find('table#sa_serial_key').parent().html( response );
                                jQuery('div#woocommerce-serial-key-details').find('table#sa_serial_key').find('[id^=\"edit_serial_key_\"]').bind('click', function(){ handle_edit_serial_key( jQuery(this) ) });
                            }
                        }
                    });
                });
                ";

        $this->enqueue_js( $js );

        $this->serial_key_meta_box_content( $post->ID );

    }

    function serial_key_meta_box_content( $order_id = 0 ) {

        if ( empty( $order_id ) ) return;

        $order = $this->get_order( $order_id );
        $order_items = $order->get_items();

        $serial_keys = $this->get_products_serial_keys( array( $order->id ) );

        if ( isset( $order_items ) && count( $order_items ) > 0 ) {
            ?>
                <table id="sa_serial_key" cellspacing="5px">
            <?php
            foreach ( $order_items as $item ) {
                $is_serial_key_generated = true;
                $item_id = ( isset( $item['variation_id'] ) && $item['variation_id'] > 0 ) ? $item['variation_id'] : $item['product_id'];
                $is_serial_key_enabled = get_post_meta( $item_id, '_serial_key', true );
                if ( $is_serial_key_enabled != 'yes' ) continue;
                $is_downloadable = get_post_meta( $item_id, '_downloadable', true );
                if ( $is_downloadable != 'yes' ) {
                    continue;
                }
                if ( !isset( $serial_keys[$item_id] ) || empty( $serial_keys[$item_id] ) ) {
                    $is_serial_key_generated = false;
                }
                $variation_data = array();
                foreach ( $item['item_meta'] as $item_meta_key => $item_meta_value ) {
                    if ( strpos( $item_meta_key, 'pa_' ) !== false ) {
                        $variation_data['attribute_'.$item_meta_key] = ( isset( $item_meta_value[0] ) && !empty( $item_meta_value[0] ) ) ? $item_meta_value[0] : '';
                    }
                }
                $variation = woocommerce_get_formatted_variation( $variation_data, true );
                if ( !empty( $variation ) ) {
                    $variation = ' (' . $variation . ')';
                }
            ?>
                <tr id="table_row_<?php echo $order->id . '_' . $item_id; ?>">
                    <td><label for="serial_key_<?php echo $order->id . '_' . $item_id; ?>"><strong><?php echo $item['name'] . $variation; ?></strong></label></td>
                    <td>
                        <?php if ( $is_serial_key_generated ) { ?>
                        <input size="50" type="text" id="serial_key_<?php echo $order->id . '_' . $item_id; ?>" name="serial_key_<?php echo $order->id . '_' . $item_id; ?>" value="<?php echo $serial_keys[$item_id]; ?>" disabled />
                        <?php } else { ?>
                        <small><i><label><?php echo __( '<span class="dashicons dashicons-info" style="color:#edbb00"></span>&nbsp;No Serial Key Found', 'localize_woocommerce_serial_key' ); ?></label></i></small>&nbsp;
                        <a id="generate_serial_key_<?php echo $order->id . '_' . $item_id; ?>" href=""><?php echo __( 'Generate', 'localize_woocommerce_serial_key' ); ?></a>
                        <?php } ?>
                    </td>
                    <td>
                        <?php if ( $is_serial_key_generated ) { ?>
                        <span id="edit_serial_key_<?php echo $order->id . '_' . $item_id; ?>" class="dashicons dashicons-edit" style="cursor: pointer;"></span>
                        <?php } ?>
                    </td>
                </tr>
                <tr id="message_row_<?php echo $order->id . '_' . $item_id; ?>" style="display: none;">
                    <td></td>
                    <td>
                        <small><label></label></small>
                    </td>
                    <td></td>
                </tr>
            <?php
            }
            ?>
                </table>   
            <?php

        }

    }

    function get_products_serial_keys( $order_ids = array(), $user_ids = array() ) {
        
        if ( empty( $order_ids ) && empty( $user_ids ) ) {
            return false;
        }

        global $wpdb;

        $user_order_ids = array();

        if ( !empty( $user_ids ) ) {

            $user_order_ids_query = "SELECT postmeta.post_id FROM {$wpdb->prefix}postmeta AS postmeta 
                                            LEFT JOIN {$wpdb->prefix}woocommerce_serial_key AS woocommerce_serial_key
                                                ON ( woocommerce_serial_key.order_id = postmeta.post_id )
                                            WHERE postmeta.meta_key LIKE '_customer_user'
                                            AND postmeta.meta_value IN ( " . implode( ',', $user_ids ) . " )";

            $user_order_ids = $wpdb->get_col( $user_order_ids_query );

        }

        $new_order_ids = array_unique( array_merge( $user_order_ids, $order_ids ) );

        if ( empty( $new_order_ids ) ) {
            return false;
        }

        $keys_details = $wpdb->get_results("SELECT product_id, serial_key FROM {$wpdb->prefix}woocommerce_serial_key WHERE order_id IN ( " . implode( ',', $new_order_ids ) . ")", 'ARRAY_A');
        $serial_keys = array();
        foreach ( $keys_details as $keys_detail ) {
            $serial_keys[$keys_detail['product_id']] = $keys_detail['serial_key'];
        }

        return $serial_keys;

    }

    function enqueue_serial_key_admin_js() {

        $js= "var showHideMetaField = function( element ){
                    if ( element.find('input[name^=\"_serial_key\"]').is(':checked') ) {
                        element.next('tr, .serial_key_meta_fields').show();
                    } else {
                        element.next('tr, .serial_key_meta_fields').hide();
                    }
              };
              showHideMetaField( jQuery('input[name^=\"_serial_key\"]').closest('tr, p') );

              jQuery('input[name^=\"_serial_key\"]').on('change', function(){
                    setTimeout( showHideMetaField( jQuery(this).closest('tr, p') ), 10 );
              });
            ";

        $this->enqueue_js( $js );
    }
    
    // Function to show checkbox to generate serial key for simple product
    function woocommerce_product_options_serial_key_simple() {

        $this->enqueue_serial_key_admin_js();
        
        woocommerce_wp_checkbox( array( 'id' => '_serial_key', 'wrapper_class' => 'show_if_simple', 'label' => __('Generate Serial Key', 'localize_woocommerce_serial_key'), 'description' => __('Enable this option to generate a serial key for the product.', 'localize_woocommerce_serial_key') ) );

        echo '<div class="serial_key_meta_fields">';

        woocommerce_wp_text_input( array( 'id' => 'serial_key_limit', 'label' => __( 'Serial Key Usage Limit.', 'localize_woocommerce_serial_key' ) . ' <a target="_blank" href="' . admin_url( 'admin.php?page=woocommerce_serial_key' ) . '">' . __( 'How to track usage', 'localize_woocommerce_serial_key' ) . '</a>', 'placeholder' => __( 'Unlimited', 'localize_woocommerce_serial_key' ), 'description' => __( 'Leave blank for unlimited usage.', 'localize_woocommerce_serial_key' ), 'type' => 'number', 'custom_attributes' => array(
            'step'  => '1',
            'min'   => '0'
        ) ) );

        woocommerce_wp_checkbox( array( 'id' => 'is_update_serial_key_limit', 'wrapper_class' => 'show_if_simple', 'label' => __('Update limit for previous serial keys?', 'localize_woocommerce_serial_key'), 'description' => __('Check to update serial key usage limit for previous orders.', 'localize_woocommerce_serial_key') ) );

        echo '</div>';
        
    }
    
    // Function to show checkbox to generate serial key for variable product
    function woocommerce_product_options_serial_key_variable( $loop, $variation_data, $variation ) {

        $this->enqueue_serial_key_admin_js();

        if ( $this->is_wc_gte_23() ) {
        
        $variation_id = $variation->ID;

        ?>
        
        <div class="show_if_variation_downloadable">
            <p class="form-row form-row-first">
                <label>
                    <?php $generate = get_post_meta($variation->ID, '_serial_key',true); ?>
                    <input type="checkbox" class="checkbox" <?php echo ($generate == 'yes') ? "checked='checked'" : ""; ?>  name="_serial_key[<?php echo $loop; ?>]">
                    <?php _e('Generate Serial Key', 'localize_woocommerce_serial_key'); ?> <a class="tips" data-tip="<?php _e('Enable this option to generate serial key for the product', 'localize_woocommerce_serial_key'); ?>" href="#">[?]</a>
                </label>
            </p>
            <p class="form-row form-row-last">
                <label>
                    <input type="checkbox" class="checkbox" name="is_update_serial_key_limit[<?php echo $loop; ?>]" /> 
                    <?php _e('Update limit for previous serial keys?', 'localize_woocommerce_serial_key'); ?> <a class="tips" data-tip="<?php _e('Check to update serial key usage limit for previous orders', 'localize_woocommerce_serial_key'); ?>" href="#">[?]</a>
                </label>
            </p>
            <p class="form-row form-row-full">
                <label>
                    <?php $serial_key_limit = get_post_meta($variation->ID,'serial_key_limit',true); ?>
                    <?php echo __('Serial Key Usage Limit', 'localize_woocommerce_serial_key') . ' <a target="_blank" href="' . admin_url( 'admin.php?page=woocommerce_serial_key' ) . '">' . __( 'How to track usage', 'localize_woocommerce_serial_key' ) . '</a>'; ?> <a class="tips" data-tip="<?php _e('Leave blank for unlimited usage', 'localize_woocommerce_serial_key'); ?>" href="#">[?]</a>
                    <input type="number" placeholder="<?php _e( 'Unlimited', 'localize_woocommerce_serial_key' ); ?>" step="1" min="0" name="serial_key_limit[<?php echo $loop; ?>]" value="<?php echo (isset($serial_key_limit) ? $serial_key_limit : ''); ?>" />
                </label>
            </p>
        </div>

        <?php } else { ?>
            <tr>
                <td colspan="2">
                    <div class="show_if_variation_downloadable">
                        <label><input type="checkbox" class="checkbox" name="_serial_key[<?php echo $loop; ?>]" <?php if (isset($variation_data['_serial_key'][0])) checked($variation_data['_serial_key'][0], 'yes'); ?> /> <?php _e('Generate Serial Key', 'localize_woocommerce_serial_key'); ?> <a class="tips" data-tip="<?php _e('Enable this option to generate serial key for the product', 'localize_woocommerce_serial_key'); ?>" href="#">[?]</a></label>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div class="show_if_variation_downloadable">
                        <label><?php echo __('Serial Key Usage Limit', 'localize_woocommerce_serial_key') . ' <a target="_blank" href="' . admin_url( 'admin.php?page=woocommerce_serial_key' ) . '">' . __( 'How to track usage', 'localize_woocommerce_serial_key' ) . '</a>'; ?> <input type="number" placeholder="<?php _e( 'Unlimited', 'localize_woocommerce_serial_key' ); ?>" step="1" min="0" name="serial_key_limit[<?php echo $loop; ?>]" value="<?php echo (isset($variation_data['serial_key_limit'][0])) ? $variation_data['serial_key_limit'][0] : ''; ?>" /> <a class="tips" data-tip="<?php _e('Leave blank for unlimited usage', 'localize_woocommerce_serial_key'); ?>" href="#">[?]</a></label>
                    </div>
                </td>
                <td>
                    <div class="show_if_variation_downloadable">
                        <label><input type="checkbox" class="checkbox" name="is_update_serial_key_limit[<?php echo $loop; ?>]" /> <?php _e('Update limit for previous serial keys?', 'localize_woocommerce_serial_key'); ?> <a class="tips" data-tip="<?php _e('Check to update serial key usage limit for previous orders', 'localize_woocommerce_serial_key'); ?>" href="#">[?]</a></label>
                    </div>
                </td>
            </tr>
        <?php } ?>

        
        <?php
    }
    
    // Function to show checkbox to generate serial key when variation is added through JS
    function woocommerce_product_options_serial_key_variable_js() {

        if ( $this->is_wc_gte_20() ) return;

        ?>
            <tr>\
                <td colspan="2">\
                    <div class="show_if_variation_downloadable"><label><input type="checkbox" class="checkbox" name="_serial_key[' + loop + ']" /> <?php echo esc_js( __('Generate Serial Key', 'localize_woocommerce_serial_key') ); ?> <a class="tips" data-tip="<?php echo esc_js( __('Enable this option to generate serial key for the product.', 'localize_woocommerce_serial_key') ); ?>" href="#">[?]</a></label></div>\
                </td>\
            </tr>\
            <tr>\
                <td>\
                    <div class="show_if_variation_downloadable"><label><?php echo esc_js( __('Serial Key Usage Limit', 'localize_woocommerce_serial_key') ) . ' <a target="_blank" href="' . admin_url( 'admin.php?page=woocommerce_serial_key' ) . '">' . esc_js( __( 'How to track usage', 'localize_woocommerce_serial_key' ) ) . '</a>'; ?> <input type="number" placeholder="<?php echo esc_js( __( 'Unlimited', 'localize_woocommerce_serial_key' ) ); ?>" name="serial_key_limit[' + loop + ']" value=""/> <a class="tips" data-tip="<?php echo esc_js( __('Leave blank for unlimited usage', 'localize_woocommerce_serial_key') ); ?>" href="#">[?]</a></label></div>\
                </td>\
                <td>\
                    <div class="show_if_variation_downloadable">\
                        <label><input type="checkbox" class="checkbox" name="is_update_serial_key_limit[' + loop + ']" /> <?php echo esc_js( __('Update limit for previous serial keys?', 'localize_woocommerce_serial_key') ); ?> <a class="tips" data-tip="<?php echo esc_js( __('Check to update serial key usage limit for previous orders', 'localize_woocommerce_serial_key') ); ?>" href="#">[?]</a></label>\
                    </div>\
                </td>\
            </tr>\
        <?php
    }

    function woocommerce_generate_serial_key( $order_id, $product_ids = array() ) {

        global $wpdb;
        
        $order = $this->get_order( $order_id );
        $order_items = (array) $order->get_items();
        
        foreach( $order_items as $item ) { 
            
            $product = $order->get_product_from_item( $item );
            
            if ( $product instanceof WC_Product_Variation ) {
                $product_id = $product->variation_id;
            } else {
                $product_id = $product->id;
            }

            if ( ! empty( $product_ids ) && ! in_array( $product_id, $product_ids ) ) {
                continue;
            }
            
            if ( $product->is_downloadable() && get_post_meta( $product_id, '_serial_key', true ) == 'yes' ) {                      
                $serial_key = $wpdb->query( "SELECT serial_key FROM {$wpdb->prefix}woocommerce_serial_key WHERE order_id = $order_id AND product_id = $product_id" );
                
                if ( ! $serial_key ) {                          
                    $serial_key = $this->generate_serial_key(); 
                    $expiry     = trim( get_post_meta( $product_id, '_download_expiry', true ) );
                    $expiry     = empty( $expiry ) ? null : absint( $expiry );

                    if ( $expiry ) {
                        $order_completed_date = date( "Y-m-d H:i:s", strtotime( $order->completed_date ) );
                        $expiry = date( "Y-m-d H:i:s", strtotime( $order_completed_date . ' + ' . $expiry . ' DAY' ) );
                    }

                    $limit = get_post_meta( $product_id, 'serial_key_limit', true );
                    $limit = ( !empty( $limit ) ) ? $limit : NULL;
                    $wpdb->query( "INSERT INTO {$wpdb->prefix}woocommerce_serial_key ( `order_id`, `product_id`, `serial_key`, `valid_till`, `limit` ) VALUES ( $order_id, $product_id, '$serial_key', '$expiry', '$limit' )" );
                }                       
            }
        }

    }
    
    // Function to generate serial key on order completion, but only when the serial key for that order & that product is not available
    function generate_serial_key_from_order( $order_id ) {

        $this->woocommerce_generate_serial_key( $order_id, array() );

    }
    
    // Function for generating random serial key
    function generate_serial_key() {
        
        $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $len = strlen( $chars );
        $full_serial = '';
        
        for ( $i = 0; $i < 6; $i++ ) {
            $part_serial = '';
            for ( $j = 0; $j < 6; $j++ ) {
                $random = $chars[ rand( 0, ( $len - 1 ) ) ];
                $part_serial .= $random;
            }

            if ( empty( $full_serial ) ) {  
                $full_serial .= $part_serial;
            } else {
                $full_serial .= "-". $part_serial;  
            }                   
        }
        
        return $full_serial;
    }
    
    // Function for saving checkbox value for generating serial key for simple product
    function woocommerce_process_product_meta_serial_simple( $post_id ) {
        
        if ( isset( $_POST['_serial_key'] ) ) {
            update_post_meta( $post_id, '_serial_key', 'yes' );
        } else {
            update_post_meta( $post_id, '_serial_key', 'no' );
        }

        if ( isset( $_POST['serial_key_limit'] ) ) {
            update_post_meta( $post_id, 'serial_key_limit', $_POST['serial_key_limit'] );
        }

        if ( isset( $_POST['is_update_serial_key_limit'] ) ) {
            $this->sync_serial_key_usage( array( $post_id ) );
        }
        
    }
    
    // Function for saving checkbox value for generating serial key for variable product
    function woocommerce_process_product_meta_variable_serial( $post_id ) {

        if ( empty( $_POST['variable_post_id'] ) ) return;

        $max_loop = max( array_keys( $_POST['variable_post_id'] ) );

        for ( $i = 0; $i <= $max_loop; $i++ ) {
            if ( isset( $_POST['variable_post_id'][$i] ) ) {
                if ( isset( $_POST['variable_is_downloadable'][$i] ) && isset( $_POST['_serial_key'][$i] ) ) {
                    update_post_meta( $_POST['variable_post_id'][$i], '_serial_key', 'yes' );
                } else {
                    update_post_meta( $_POST['variable_post_id'][$i], '_serial_key', 'no' );
                }

                if ( isset( $_POST['variable_is_downloadable'][$i] ) && isset( $_POST['serial_key_limit'][$i] ) ) {
                    update_post_meta( $_POST['variable_post_id'][$i], 'serial_key_limit', $_POST['serial_key_limit'][$i] );
                }

                if ( isset( $_POST['variable_is_downloadable'][$i] ) && isset( $_POST['is_update_serial_key_limit'][$i] ) ) {
                    $this->sync_serial_key_usage( array( $_POST['variable_post_id'][$i] ) );
                }
            }                   
        }               
    }

    function woocommerce_settings_serial_key_tab( $tabs ) {

        $tabs['serial_key'] = __( 'Serial Key', 'localize_woocommerce_serial_key' );
        return $tabs;

    }

    function woocommerce_serial_key_page_content() {
        global $wpdb;

        $sku = $wpdb->get_var("SELECT postmeta.meta_value
                                FROM {$wpdb->prefix}postmeta AS postmeta
                                WHERE postmeta.meta_key LIKE '_sku'
                                AND postmeta.post_id IN ( SELECT product_id FROM {$wpdb->prefix}woocommerce_serial_key )
                                ORDER BY postmeta.meta_id DESC
                                LIMIT 1");

        if ( isset( $_POST['save_serial_key_settings'] ) && $_POST['save_serial_key_settings'] != '' ) {
            if ( isset( $_POST['uuid_display_name'] ) ) {
                update_option( 'serial_key_uuid_display_name', $_POST['uuid_display_name'] );
            }
            if ( isset( $_POST['is_synce_serial_key_usage'] ) ) {
                $this->sync_serial_key_usage( true );
            }
        }
        ?>
        <script type="text/javascript">
            jQuery(function(){
                jQuery('input#validate_serial_key_send').on('click', function(){
                    jQuery.ajax({
                        url: '<?php echo home_url("/") . "?wc-api=validate_serial_key"; ?>',
                        type: 'post',
                        dataType: 'json',
                        data: {
                            serial: jQuery('input#sa_serial_key').val(),
                            uuid: jQuery('input#sa_serial_key_uuid').val(),
                            sku: jQuery('input#sa_serial_key_sku').val()
                        },
                        success: function( response ) {
                            jQuery('textarea#validate_serial_key_response').text( JSON.stringify(response) );
                        }
                    });
                });
            });
        </script>
        <form action="" method="post">
        <h3><?php echo __( 'Settings', 'localize_woocommerce_serial_key' ); ?></h3>
        <table class="form-table">
            <tbody>
                <tr valign="top">
                    <th scope="row">
                        <label for="uuid_display_name"><?php echo __( 'Display name for UUID', 'localize_woocommerce_serial_key' ); ?></label>
                    </th>
                    <td>
                        <input id="uuid_display_name" type="text" name="uuid_display_name" value="<?php echo get_option( 'serial_key_uuid_display_name' ); ?>" /> <span class="description"><?php echo __( 'This will be displayed with UUIDs of your customers', 'localize_woocommerce_serial_key' ); ?></span>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">
                        <label for="is_synce_serial_key_usage"><?php echo __( 'Sync serial key usage?', 'localize_woocommerce_serial_key' ); ?></label>
                    </th>
                    <td>
                        <input id="is_synce_serial_key_usage" type="checkbox" name="is_synce_serial_key_usage" /> <span class="description"><?php echo __( 'Check this to sync / update existing serial key usage with usage limit of respective products', 'localize_woocommerce_serial_key' ); ?></span>
                    </td>
                </tr>
            </tbody>
        </table>
        <br />
        <input type="submit" class="button" name="save_serial_key_settings" value="<?php echo __( 'Save changes', 'localize_woocommerce_serial_key' ); ?>" />
        </form>
        <h3><?php echo __( 'Documentation', 'localize_woocommerce_serial_key' ); ?></h3>
        <p>
            <?php 
                echo __( 'To validate generated key against a product, you can send a request to ', 'localize_woocommerce_serial_key' ) . '<br><strong>' . add_query_arg( 'uuid', 'UUID', add_query_arg( 'sku', 'SKU', add_query_arg( 'serial', 'SERIAL_KEY', add_query_arg( 'wc-api', 'validate_serial_key', home_url('/') ) ) ) ) . '</strong>';
                echo __( '<br>You\'ll receive validation result in JSON format. JSON decode it to get response in array format & use it as per your requirement.', 'localize_woocommerce_serial_key' );
            ?>
        </p>
        <hr>
        <h4><?php _e( 'Live Demo Of Serial Key Validation', 'localize_woocommerce_serial_key' ); ?></h4>
        <p>
            <?php
                echo home_url('/') . '?wc-api=validate_serial_key&serial=<input type="text" size="50" id="sa_serial_key" value=""/>&sku=<input type="text" id="sa_serial_key_sku" value=""/>&uuid=<input type="text" size="50" id="sa_serial_key_uuid" value=""/> &rarr; <input type="button" id="validate_serial_key_send" value="' . __( 'Send', 'localize_woocommerce_serial_key' ) . '">';
            ?>
        </p>
        <h4><?php _e( 'Response', 'localize_woocommerce_serial_key' ); ?></h4>
        <textarea id="validate_serial_key_response" cols="100" rows="3"></textarea>
        <hr>
        <h4><?php _e( 'Example of HTML code to validate serial key', 'localize_woocommerce_serial_key' ); ?></h4>
        <p><?php echo __( 'Embed this code in your product & don\'t forget to replace ', 'localize_woocommerce_serial_key' ) . '<code>' . $sku . '</code>' . __( ' with SKU of the product in code', 'localize_woocommerce_serial_key' ); ?></p>
        <style>
            table#serial_key_table {
                width: 100%; 
                table-layout: fixed;
            }
            table#serial_key_table th {
                padding: 10px 0;
            }
            table#serial_key_table td {
                padding: 0 15px;
                vertical-align: top;
            }
            table#serial_key_table,
            table#serial_key_table th,
            table#serial_key_table td {
                border-style: solid;
                border-width: 1px;
                border-color: lightgrey;
                border-spacing: 0;
            }
            table#serial_key_table td pre {
                overflow-x: scroll;
                margin-top: 0;
            }
            div.validate_serial_key {
                padding: 15px 0;
            }
        </style>
        <table id="serial_key_table" cellspacing="0">
            <tbody>
                <tr>
                    <th><?php _e( 'Code', 'localize_woocommerce_serial_key' ); ?></th>
                    <th><?php _e( 'Output', 'localize_woocommerce_serial_key' ); ?></th>
                </tr>
                <tr>
                    <td>
                        <pre>
                            <?php $html_string = '
<div class="validate_serial_key">
    <script type="text/javascript">
        jQuery(function(){
            jQuery("input#validate").on("click", function(){
                jQuery.ajax({
                    url: "' . home_url("/") . '?wc-api=validate_serial_key",
                    type: "post",
                    dataType: "json",
                    data: {
                        serial: jQuery("input#serial_key").val(),
                        uuid: jQuery("input#serial_key_uuid").val(),
                        sku: jQuery("input#sku").val()
                    },
                    success: function( response ) {
                        jQuery("p#result").text(\'\');
                        if ( response.success == "true" ) {
                            jQuery("p#result").append( \'<p style="background: green; color: white">\'+response.message+\'.</p>\' );
                        } else {
                            jQuery("p#result").append( \'<p style="background: red; color: white">\'+response.message+\'.</p>\' );
                        }
                    }
                });
            });
        });
    </script>
    Serial Key: <input type="text" id="serial_key"><br />
    UUID: <input type="text" id="serial_key_uuid">
    <input type="button" id="validate" value="Validate">
    <input type="hidden" id="sku" value="'.$sku.'">
    <p id="result"></p>
</div>';

                                echo esc_html( $html_string );
                            ?>
                        </pre>
                    </td>
                    <td style="padding: 0 15px;">
                        <div class="validate_serial_key">
                            <script type="text/javascript">
                                jQuery(function(){
                                    jQuery("input#validate").on("click", function(){
                                        jQuery.ajax({
                                            url: '<?php echo home_url("/"); ?>?wc-api=validate_serial_key',
                                            type: "post",
                                            dataType: "json",
                                            data: {
                                                serial: jQuery("input#serial_key").val(),
                                                uuid: jQuery("input#serial_key_uuid").val(),
                                                sku: jQuery("input#sku").val()
                                            },
                                            success: function( response ) {
                                                jQuery("p#result").text('');
                                                if ( response.success == 'true' ) {
                                                    jQuery("p#result").append( '<p style="background: green; color: white">'+response.message+'.</p>' );
                                                } else {
                                                    jQuery("p#result").append( '<p style="background: red; color: white">'+response.message+'.</p>' );
                                                }
                                            }
                                        });
                                    });
                                });
                            </script>
                            Serial Key: <input type="text" id="serial_key" size="40"><br />
                            UUID: <input type="text" id="serial_key_uuid" size="40">
                            <input type="button" id="validate" value="Validate">
                            <input type="hidden" id="sku" value="<?php echo $sku; ?>">
                            <p id="result"></p>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php
    }
    
    function display_serial_keys_of_products() {
        global $wpdb;

        if ( is_user_logged_in() ) {

            $user_id = get_current_user_id();

            $serial_keys = $this->get_products_serial_keys( array(), array( $user_id ) );

            if ( empty( $serial_keys ) ) return;

            $title = __( 'Serial Keys', 'localize_woocommerce_serial_key' );

            require_once WP_PLUGIN_DIR . '/' . dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/templates/serial-keys-table.php';

        }

    }

    function display_serial_keys_after_order_table( $order ) {

        $serial_keys = $this->get_products_serial_keys( array( $order->id ), array() );

        if ( empty( $serial_keys ) ) return;

        $title = __( 'Serial Keys', 'localize_woocommerce_serial_key' );

        require_once WP_PLUGIN_DIR . '/' . dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/templates/serial-keys-table.php';

    }

    function manage_serial_key_usage_page_content() {
        global $woocommerce, $current_user, $wpdb;


        
        if ( $this->is_wc_gte_21() ) {
            nocache_headers();
        } else {
            $woocommerce->nocache();
        }
        
        if ( ! is_user_logged_in() ) {

            $this->wc_get_template( 'myaccount/form-login.php' );

        } else {

            $user_id = get_current_user_id();
            $serial_key_details_query = "SELECT wsk.order_id, wsk.product_id, wsk.serial_key, wsk.uuid
                                            FROM {$wpdb->prefix}woocommerce_serial_key AS wsk
                                                LEFT JOIN {$wpdb->prefix}postmeta AS postmeta
                                                    ON ( wsk.order_id = postmeta.post_id AND postmeta.meta_key LIKE '_customer_user' )
                                            WHERE postmeta.meta_value = '{$user_id}'";

            $serial_key_details_results = $wpdb->get_results( $serial_key_details_query, 'ARRAY_A' );
            $serial_key_usage = array();

            foreach ( $serial_key_details_results as $result ) {
                $order_id = $result['order_id'];
                $product_id = $result['product_id'];
                $serial_key = $result['serial_key'];
                $uuid = maybe_unserialize( $result['uuid'] );
                if ( !isset( $serial_key_usage[$order_id . '_' . $product_id] ) ) {
                    $serial_key_usage[$order_id . '_' . $product_id] = array();
                }
                $serial_key_usage[$order_id . '_' . $product_id]['product_title'] = $this->get_product_title( $product_id );
                $serial_key_usage[$order_id . '_' . $product_id]['serial_key'] = $serial_key;
                $serial_key_usage[$order_id . '_' . $product_id]['uuid'] = $uuid;
            }

            include(apply_filters('serial_key_usage_template', ''));

        }
    }

    function serial_key_usage_template_path( $template ) {

        $template_name  = 'serial-key-usage.php';
        $template_path  = 'woocommerce-serial-key/';
        $default_path   = untrailingslashit( str_replace( 'classes', 'templates', plugin_dir_path( __FILE__ ) ) ) . '/';

        // Look within passed path within the theme - this is priority
        $template = locate_template(
            array(
                trailingslashit( $template_path ) . $template_name,
                $template_name
            )
        );

        // Get default template
        if ( ! $template )
            $template = $default_path . $template_name;

        // Return what we found
        return $template;

    }

    function sync_serial_key_usage( $all_or_product_ids = false ) {
        global $wpdb;

        if ( $all_or_product_ids === false ) return;

        $update_serial_key_usage_limit_query = "UPDATE {$wpdb->prefix}woocommerce_serial_key AS wsk
                                                    LEFT JOIN {$wpdb->prefix}postmeta AS postmeta
                                                        ON ( postmeta.post_id = wsk.product_id 
                                                                AND postmeta.meta_key LIKE 'serial_key_limit' )
                                                    SET wsk.limit = CAST( postmeta.meta_value AS UNSIGNED )";

        if ( is_array( $all_or_product_ids ) && !empty( $all_or_product_ids ) ) {
            $update_serial_key_usage_limit_query .= " WHERE wsk.product_id IN ( " . implode( ',', $all_or_product_ids ) . " )";
        }

        $wpdb->query( $update_serial_key_usage_limit_query );

        $current_serial_key_usage_query = "SELECT `order_id`, `product_id`, `limit`, `uuid`
                                                FROM {$wpdb->prefix}woocommerce_serial_key";

        if ( is_array( $all_or_product_ids ) && !empty( $all_or_product_ids ) ) {
            $current_serial_key_usage_query .= " WHERE product_id IN ( " . implode( ',', $all_or_product_ids ) . " )";
        }

        $current_serial_key_usage_results = $wpdb->get_results( $current_serial_key_usage_query, 'ARRAY_A' );

        foreach ( $current_serial_key_usage_results as $result ) {
            if ( empty( $result['uuid'] ) ) continue;
            $uuids = maybe_unserialize( $result['uuid'] );
            if ( count( $uuids ) > $result['limit'] ) {
                $uuids = array_slice( $uuids, 0, $result['limit'] );
                $wpdb->query( "UPDATE {$wpdb->prefix}woocommerce_serial_key SET uuid = '" . maybe_serialize( $uuids ) . "' WHERE order_id = {$result['order_id']} AND product_id = {$result['product_id']}" );
            }
        }

    }

    // Function to get formatted Product's Name
    public function get_product_title ( $product_id ) {
        
        $parent_id = wp_get_post_parent_id ( $product_id );
     
        if ( $parent_id > 0 ) {
            $_product = new WC_Product_Variation( $product_id );
            $product_title = substr( get_the_title( $product_id ), strpos( get_the_title( $product_id ), 'of ')+3);
        } else {
            $_product = $this->get_product( $product_id );
            $product_title = get_the_title( $product_id );
        }

        if ( $_product instanceof WC_Product_Variation ) {
            $product_title .= ' (' . woocommerce_get_formatted_variation( $_product->get_variation_attributes(), true ) . ')';
        }

        return $product_title;
    }

    /**
     * Make meta data of this plugin, protected
     * 
     * @param bool $protected
     * @param string $meta_key
     * @param string $meta_type
     * @return bool $protected
     */
    public function make_sk_meta_protected( $protected, $meta_key, $meta_type ) {
        $sk_meta = array(
                            'serial_key_limit'
                        );
        if ( in_array( $meta_key, $sk_meta, true ) ) {
            return true;
        }
        return $protected;
    }

}