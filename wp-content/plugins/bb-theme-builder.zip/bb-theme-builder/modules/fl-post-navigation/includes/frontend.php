<?php

the_post_navigation( array(
	'prev_text' => '&larr; %title',
	'next_text' => '%title &rarr;',
) );
