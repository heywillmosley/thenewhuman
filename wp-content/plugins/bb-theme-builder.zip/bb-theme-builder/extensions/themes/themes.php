<?php

define( 'FL_THEME_BUILDER_THEMES_DIR', FL_THEME_BUILDER_DIR . 'extensions/themes/' );
define( 'FL_THEME_BUILDER_THEMES_URL', FL_THEME_BUILDER_DIR . 'extensions/themes/' );

require_once FL_THEME_BUILDER_THEMES_DIR . "classes/class-fl-theme-builder-theme-support.php";
