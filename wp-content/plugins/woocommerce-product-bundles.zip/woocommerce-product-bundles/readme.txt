=== WooCommerce Product Bundles ===

Contributors: franticpsyx
Tags: woocommerce, product, bundle, bundles, kits, simple, variable, configurable
Requires at least: 4.1
Tested up to: 4.8
Stable tag: 5.4.1
WC requires at least: 2.4
WC tested up to: 3.1
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Offer product bundles and assembled products in your WooCommerce store.

== Description ==

Create assembled products and offer product bundles by grouping simple, variable and subscription products.

Looking for help? Read the full documentation [here](http://docs.woocommerce.com/document/bundles/).
