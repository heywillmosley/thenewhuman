<div class="frm_html_field_placeholder">
<div class="howto button-secondary frm_html_field">
	<?php esc_html_e( 'This is a placeholder for your custom HTML.', 'formidable' ) ?><br/>
	<?php esc_html_e( 'You can edit this content in the field options.', 'formidable' ) ?>
</div>
</div>
